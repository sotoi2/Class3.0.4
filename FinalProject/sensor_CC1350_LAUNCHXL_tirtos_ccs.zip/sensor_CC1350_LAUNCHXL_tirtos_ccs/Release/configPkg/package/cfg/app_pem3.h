/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-F14
 */

#include <xdc/std.h>

#define HEAPMGR_CONFIG 0x80

#include <ti/sysbios/heaps/HeapCallback.h>
extern const ti_sysbios_heaps_HeapCallback_Handle heap0;

#define HEAPMGR_SIZE 0x0

#include <ti/sysbios/gates/GateMutex.h>
extern const ti_sysbios_gates_GateMutex_Handle tiposix_mqGate;

extern int xdc_runtime_Startup__EXECFXN__C;

extern int xdc_runtime_Startup__RESETFXN__C;

extern int xdc_rov_runtime_Mon__checksum;

extern int xdc_rov_runtime_Mon__write;

